"""Local, precompiled OSBI assets and Jinja components for Flask."""

from __future__ import annotations

import json
import re
from pathlib import Path
from uuid import uuid4

from flask import Blueprint, Flask, current_app, request, url_for
from markupsafe import Markup, escape

__all__ = ["OSBI"]
__version__ = "0.1.0"

_ROOT = Path(__file__).resolve().parent
_ATTRIBUTE = re.compile(r"[a-zA-Z_:][a-zA-Z0-9_:.-]*\Z")


def _html_attrs(attributes=None, reserved=()) -> Markup:
    """Escape attribute values, preserve native booleans, reject duplicate keys."""
    rendered = []
    for name, value in (attributes or {}).items():
        if not isinstance(name, str) or not _ATTRIBUTE.fullmatch(name):
            raise ValueError(f"Invalid HTML attribute: {name!r}")
        if name.lower() in reserved:
            raise ValueError(f"Use the component parameter instead of attrs[{name!r}].")
        if value is None:
            continue
        if isinstance(value, bool):
            if name.startswith(("aria-", "data-")):
                value = str(value).lower()
            elif value:
                value = ""
            else:
                continue
        rendered.append(f' {name}="{escape(str(value))}"')
    return Markup("".join(rendered))


def _asset(filename: str) -> str:
    state = current_app.extensions["osbi"]
    return url_for("osbi.static", filename=filename, v=state["revision"])


def _choice(value, allowed):
    if value not in allowed:
        raise ValueError(f"Unsupported OSBI option {value!r}; choose from {', '.join(allowed)}.")
    return value


def _css() -> Markup:
    return Markup('<link rel="stylesheet" href="{}">').format(_asset("osbi.min.css"))


def _js() -> Markup:
    return Markup('<script src="{}" defer></script>').format(_asset("osbi.min.js"))


class _AssetBlueprint(Blueprint):
    def send_static_file(self, filename):
        # Precompression keeps Node and compression work out of the host app.
        compressed = (
            current_app.config["OSBI_USE_GZIP"]
            and filename in {"osbi.min.css", "osbi.min.js"}
            and request.accept_encodings["gzip"] > 0
            and request.accept_encodings["gzip"] >= request.accept_encodings["identity"]
        )
        response = super().send_static_file(filename + ".gz" if compressed else filename)
        if compressed:
            response.headers["Content-Encoding"] = "gzip"
            response.mimetype = "text/css" if filename.endswith(".css") else "text/javascript"
        if filename in {"osbi.min.css", "osbi.min.js"}:
            response.vary.add("Accept-Encoding")
        return response


class OSBI:
    """Register OSBI on one or more applications, including application factories.

    Configuration is read from each application's ``OSBI_URL_PREFIX`` and
    ``OSBI_USE_GZIP`` keys. Templates may use ``osbi_css()``, ``osbi_js()`` and
    ``osbi_asset(filename)`` without importing the extension instance.
    """

    def __init__(self, app: Flask | None = None):
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask) -> None:
        if "osbi" in app.extensions or "osbi" in app.blueprints:
            raise RuntimeError("OSBI is already registered or the 'osbi' blueprint name is in use.")

        manifest_path = _ROOT / "static" / "manifest.json"
        if not manifest_path.is_file():
            raise RuntimeError(
                "OSBI assets are missing. In the OSBI source repository, run "
                "'npm run build:flask' before installing the Python package."
            )
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for filename in ("osbi.min.css", "osbi.min.js"):
            if not (_ROOT / "static" / filename).is_file():
                raise RuntimeError(f"OSBI asset {filename!r} is missing. Run 'npm run build:flask'.")

        app.config.setdefault("OSBI_URL_PREFIX", "/_osbi")
        app.config.setdefault("OSBI_USE_GZIP", True)
        prefix = app.config["OSBI_URL_PREFIX"]
        if not isinstance(prefix, str) or not prefix.startswith("/") or "<" in prefix or "?" in prefix or "#" in prefix:
            raise ValueError("OSBI_URL_PREFIX must be an absolute URL path without route variables.")

        blueprint = _AssetBlueprint(
            "osbi", __name__, static_folder="static", static_url_path="/static",
            template_folder="templates", url_prefix=prefix.rstrip("/"),
        )
        app.register_blueprint(blueprint)
        app.extensions["osbi"] = {"extension": self, "revision": manifest["revision"]}
        app.jinja_env.globals.update(
            osbi_asset=_asset, osbi_css=_css, osbi_js=_js,
            osbi_id=lambda: "osbi-" + uuid4().hex,
            osbi_attrs=_html_attrs, osbi_choice=_choice,
        )
